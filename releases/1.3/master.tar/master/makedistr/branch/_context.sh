#!/bin/bash

export LAST_PROD_TAG=`cat last-prod-tag.txt`

C_CONTEXT_VERSIONMODE=branch
